package com.ctbc.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ctbc.po.TagPO;

public interface TagRepository extends JpaRepository<TagPO, Long> {

	public TagPO findByName(String name);

}
