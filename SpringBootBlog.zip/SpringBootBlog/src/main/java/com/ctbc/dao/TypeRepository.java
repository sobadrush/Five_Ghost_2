package com.ctbc.dao;

import com.ctbc.po.TypePO;

public interface TypeRepository extends JpaRepository<TypePO, Long> {

}
