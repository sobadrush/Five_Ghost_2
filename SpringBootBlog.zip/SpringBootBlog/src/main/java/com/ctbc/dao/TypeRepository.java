package com.ctbc.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ctbc.po.TypePO;

public interface TypeRepository extends JpaRepository<TypePO, Long> {
	
	public TypePO findByName(String name);

}
