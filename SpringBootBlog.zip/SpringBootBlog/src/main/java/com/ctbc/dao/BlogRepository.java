package com.ctbc.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.ctbc.po.BlogPO;

public interface BlogRepository extends JpaRepository<BlogPO, Long>, JpaSpecificationExecutor<BlogPO> {

}
