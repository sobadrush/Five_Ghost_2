package com.ctbc.dao;

import com.ctbc.po.UserPO;

public interface UserRepository extends JpaRepository<UserPO, Long> {

	public UserPO findByUsernmaeAndPassword(String username, String password);

}
