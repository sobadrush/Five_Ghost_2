package com.ctbc.web.admin;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ctbc.po.TypePO;
import com.ctbc.service.TypeService;

@Controller
@RequestMapping("/admin")
public class TypeController {

	@Autowired
	private TypeService typeService;

	@GetMapping("/types")
	public String types2(
			// 自動分頁
			@PageableDefault(size = 10, sort = { "id" }, direction = Sort.Direction.DESC) Pageable pageable,
			Model model) {

		model.addAttribute("page", typeService.listType(pageable));

		return "admin/types";
	}

	@GetMapping("/types/input")
	public String input(Model model) {
		model.addAttribute("type", new TypePO()); // 配合前端的th:object，為了要使用後端驗證
		return "admin/types-input";
	}

	@GetMapping("/types/{id}/input")
	public String editInput(@PathVariable Long id, Model model) {
		model.addAttribute("type", typeService.getType(id));
		return "admin/type-input";
	}

	@PostMapping("/types")
	// @Valid後面一定要跟著BindingResult，不然檢驗會沒有效果
	public String post(@Valid TypePO type, BindingResult result, RedirectAttributes attributes) {
		TypePO typeExistResult = typeService.getTypeByName(type.getName());

		if (typeExistResult != null) {
			result.rejectValue("name", "nameError", "不能添加重複分類");
		}

		// 如果不符合PO上的驗證，就會有錯誤
		if (result.hasErrors()) {
			return "admin/types-input";
		}

		TypePO typeResult = typeService.saveType(type);
		if (typeResult == null) {
			attributes.addFlashAttribute("message", "新增失敗");
		} else {
			attributes.addFlashAttribute("message", "新增成功");
		}

		return "redirect:/admin/types";
	}

	@PostMapping("/types/{id}")
	public String editPost(@Valid TypePO type, BindingResult result, @PathVariable Long id,
			RedirectAttributes attributes) {
		TypePO typeExistResult = typeService.getTypeByName(type.getName());

		if (typeExistResult != null) {
			result.rejectValue("name", "nameError", "不能添加重複分類");
		}

		// 如果不符合PO上的驗證，就會有錯誤
		if (result.hasErrors()) {
			return "admin/types-input";
		}

		TypePO typeResult = typeService.updateType(id, type);
		if (typeResult == null) {
			attributes.addFlashAttribute("message", "更新失敗");
		} else {
			attributes.addFlashAttribute("message", "更新成功");
		}

		return "redirect:/admin/types";
	}

	@GetMapping("/types/{id}/delete")
	public String delete(@PathVariable Long id,RedirectAttributes attributes) {
		typeService.deleteType(id);
		attributes.addFlashAttribute("message", "刪除成功");
		return "redirect:/admin/types";
	}

}
