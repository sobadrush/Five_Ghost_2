package com.ctbc.web.admin;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.ctbc.po.BlogPO;
import com.ctbc.po.UserPO;
import com.ctbc.service.BlogService;
import com.ctbc.service.TagService;
import com.ctbc.service.TypeService;
import com.ctbc.vo.BlogQuery;

@Controller
@RequestMapping("/admin")
public class BlogController {

	private static final String INPUT = "admin/blogs-input";
	private static final String LIST = "admin/blogs";
	private static final String REDIRECT_LIST = "redirect:/admin/blogs";

	@Autowired
	private BlogService blogService;
	@Autowired
	private TypeService typeService;
	@Autowired
	private TagService tagService;

	@GetMapping("/blogs")
	public String blogs(
			@PageableDefault(size = 3, sort = { "updateTime" }, direction = Sort.Direction.DESC) Pageable pageable,
			BlogQuery blog, Model model) {
		model.addAttribute("types", typeService.listType());
		model.addAttribute("page", blogService.listBlog(pageable, blog));
		return LIST;
	}

	@PostMapping("/blogs/search")
	public String search(
			@PageableDefault(size = 3, sort = { "updateTime" }, direction = Sort.Direction.DESC) Pageable pageable,
			BlogQuery blog, Model model) {
		model.addAttribute("page", blogService.listBlog(pageable, blog));
		return "admin/blogs :: blogList"; // blogList的片段，實現局部渲染
	}

	@GetMapping("/blogs/input")
	public String input(Model model) {
		model.addAttribute("types", typeService.listType());
		model.addAttribute("tags", tagService.listTag());
		model.addAttribute("blog", new BlogPO());
		return INPUT;
	}

	@PostMapping("/blogs")
	public String post(BlogPO blog, RedirectAttributes attributes, HttpSession session) {
		blog.setUsers((UserPO) session.getAttribute("user")); // 當前的登入用戶
		blog.setTypePO(typeService.getType(blog.getTypePO().getId())); // type是從前端附值過來的
		blog.setTags(tagService.);
		
		BlogPO blogResult = blogService.saveBlog(blog);
		if (blogResult == null) {
			attributes.addFlashAttribute("message", "操作失敗");
		} else {
			attributes.addFlashAttribute("message", "操作成功");
		}

		return REDIRECT_LIST;
	}

}
