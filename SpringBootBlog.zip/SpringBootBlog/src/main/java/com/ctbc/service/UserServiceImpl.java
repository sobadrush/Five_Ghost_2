package com.ctbc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ctbc.dao.UserRepository;
import com.ctbc.po.UserPO;
import com.ctbc.util.MD5Utils;

@Service
public class UserServiceImpl implements UserService {

	 @Autowired
	 private UserRepository userRepository;

	@Override
	public UserPO checkUser(String username, String password) {
		// 檢查登入
		UserPO user = userRepository.findByUsernameAndPassword(username, MD5Utils.code(password));
//		if ("enzo".equals(username) && MD5Utils.code("1234").equals(MD5Utils.code(password))) {
//			UserPO user = new UserPO();
//			user.setUsername(username);
//			user.setPassword(password);
//			return user;
//		}

		return null;
	}

}
