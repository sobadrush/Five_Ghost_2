package com.ctbc.service;

import com.ctbc.po.UserPO;

public interface UserService {

	public UserPO checkUser(String username, String password);

}
