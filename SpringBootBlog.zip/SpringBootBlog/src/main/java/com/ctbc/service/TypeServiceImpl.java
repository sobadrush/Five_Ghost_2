package com.ctbc.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ctbc.NotFoundException;
import com.ctbc.dao.TypeRepository;
import com.ctbc.po.TypePO;

@Service
public class TypeServiceImpl implements TypeService {

	@Autowired
	private TypeRepository typeRepository;

	@Transactional
	@Override
	public TypePO saveType(TypePO type) {
		return typeRepository.save(type);
	}

	@Transactional
	@Override
	public TypePO getType(Long id) {
		return typeRepository.findOne(id);
	}

	@Override
	public TypePO getTypeByName(String name) {
		return typeRepository.findByName(name);
	}

	@Transactional
	@Override
	public Page<TypePO> listType(Pageable pageable) {
		return typeRepository.findAll(pageable);
	}

	@Override
	public List<TypePO> listType() {
		return typeRepository.findAll();
	}

	@Transactional
	@Override
	public TypePO updateType(Long id, TypePO type) {
		TypePO typeResult = typeRepository.findOne(id);
		if (typeResult == null) {
			throw new NotFoundException("不存在該類型");
		}
		BeanUtils.copyProperties(type, typeResult);

		return typeRepository.save(typeResult);
	}

	@Transactional
	@Override
	public void deleteType(Long id) {
		typeRepository.delete(id);
	}

}
