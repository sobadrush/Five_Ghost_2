package com.ctbc.service;

import com.ctbc.po.TypePO;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface TypeService {

	public TypePO saveType(TypePO type);

	public TypePO getType(Long id);
	
	public TypePO getTypeByName(String name);

	public Page<TypePO> listType(Pageable pageable);
	
	public List<TypePO> listType();

	public TypePO updateType(Long id, TypePO type);

	public void deleteType(Long id);
}
