package com.ctbc.service;

import com.ctbc.po.TypePO;

import org.springframework.data.domain.Page;

public interface TypeService {

	public TypePO saveType(TypePO type);

	public TypePO getType(Long id);

	 public Page<TypePO> listType(Pageable pageable);

	public TypePO updateType(Long id, TypePO type);

	public void deleteType(Long id);
}
