package com.ctbc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ctbc.NotFoundException;
import com.ctbc.dao.TagRepository;
import com.ctbc.po.TagPO;

@Service
public class TagServiceImpl implements TagService {

	@Autowired
	private TagRepository tagRepository;

	@Transactional
	@Override
	public TagPO saveTag(TagPO tag) {
		return tagRepository.save(tag);
	}

	@Transactional
	@Override
	public TagPO getTag(Long id) {
		return tagRepository.findOne(id);
	}

	@Transactional
	@Override
	public TagPO getTagByName(String name) {
		return tagRepository.findByName(name);
	}

	@Transactional
	@Override
	public Page<TagPO> listTag(Pageable pageable) {
		return tagRepository.findAll(pageable);
	}

	@Transactional
	@Override
	public List<TagPO> listTag() {
		return tagRepository.findAll();
	}
	
	@Transactional
	@Override
	public List<TagPO> listTag(String ids) {
		return tagRepository.findAll(ids);
	}
	
	private List<Long> converToList(String ids){
		List<Long> list = new ArrayList<>();
		if () {
			String[] idarray = ids.split(",");
			for (int i = 0; i < idarray.length; i++) {
				list.add(new Long(idarray[i]));
			}
		}
	}

	@Transactional
	@Override
	public TagPO updateTag(Long id, TagPO tag) {
		TagPO tagResult = tagRepository.findOne(id);
		if (tagResult == null) {
			throw new NotFoundException("不存在該標籤");
		}
		BeanUtils.copyProperties(tag, tagResult);
		return tagRepository.save(tagResult);
	}

	@Transactional
	@Override
	public void deleteTag(Long id) {
		tagRepository.delete(id);
	}

}
