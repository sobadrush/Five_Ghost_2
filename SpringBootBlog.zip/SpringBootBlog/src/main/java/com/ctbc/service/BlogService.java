package com.ctbc.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.ctbc.po.BlogPO;
import com.ctbc.vo.BlogQuery;

public interface BlogService {

	public BlogPO getBlog(Long id);

	public Page<BlogPO> listBlog(Pageable pageable, BlogQuery blog);

	public BlogPO saveBlog(BlogPO blog);

	public BlogPO updateBlog(Long id, BlogPO blog);

	public void deleteBlog(Long id);

}
