package com.ctbc.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.ctbc.po.TagPO;

public interface TagService {

	public TagPO saveTag(TagPO tag);

	public TagPO getTag(Long id);

	public TagPO getTagByName(String name);

	public Page<TagPO> listTag(Pageable pageable);

	public List<TagPO> listTag();

	public List<TagPO> listTag(String ids);

	public TagPO updateTag(Long id, TagPO tag);

	public void deleteTag(Long id);

}
