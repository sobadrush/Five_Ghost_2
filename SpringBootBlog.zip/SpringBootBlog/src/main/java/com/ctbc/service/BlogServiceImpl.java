package com.ctbc.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.ctbc.NotFoundException;
import com.ctbc.dao.BlogRepository;
import com.ctbc.po.BlogPO;
import com.ctbc.po.TypePO;
import com.ctbc.vo.BlogQuery;

@Service
public class BlogServiceImpl implements BlogService {

	@Autowired
	private BlogRepository blogRepository;

	@Override
	public BlogPO getBlog(Long id) {
		return blogRepository.findOne(id);
	}

	@Override
	public Page<BlogPO> listBlog(Pageable pageable, BlogQuery blog) {
		return blogRepository.findAll(new Specification<BlogPO>() {
			@Override
			public Predicate toPredicate(Root<BlogPO> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predicates = new ArrayList<>();
				// 標題
				if (!"".equals(blog.getTitle()) && blog.getTitle() != null) {
					predicates.add(cb.like(root.<String>get("title"), "%" + blog.getTitle() + "%"));
				}

				// 分類
				if (blog.getTypeId() != null) {
					predicates.add(cb.equal(root.<TypePO>get("type").get("id"), blog.getTypeId()));
				}

				// 推薦
				if (blog.isRecommend()) {
					predicates.add(cb.equal(root.<Boolean>get("recommend"), blog.isRecommend()));
				}

				query.where(predicates.toArray(new Predicate[predicates.size()]));

				return null;
			}
		}, pageable);
	}

	@Override
	public BlogPO saveBlog(BlogPO blog) {
		blog.setCreateTime(new Date());
		blog.setUpdateTime(new Date());
		blog.setViews(0);
		return blogRepository.save(blog);
	}

	@Override
	public BlogPO updateBlog(Long id, BlogPO blog) {
		BlogPO blogResult = blogRepository.findOne(id);
		if (blogResult == null) {
			throw new NotFoundException("該博客不存在");
		}
		BeanUtils.copyProperties(blogResult, blog);
		return blogRepository.save(blogResult);
	}

	@Override
	public void deleteBlog(Long id) {
		blogRepository.delete(id);
	}

}
