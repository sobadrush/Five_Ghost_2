package com.ctbc.po;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "t_tag")
public class TagPO {

	@Id
	@GeneratedValue
	private Long id;
	private String name;

	@ManyToMany(mappedBy = "tags")
	private List<BlogPO> blogs = new ArrayList<>();

	public TagPO() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<BlogPO> getBlogs() {
		return blogs;
	}

	public void setBlogs(List<BlogPO> blogs) {
		this.blogs = blogs;
	}

	@Override
	public String toString() {
		return "TagPO [id=" + id + ", name=" + name + "]";
	}

}
