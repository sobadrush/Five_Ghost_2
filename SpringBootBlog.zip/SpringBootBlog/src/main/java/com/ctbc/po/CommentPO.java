package com.ctbc.po;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "t_comment")
public class CommentPO {

	@Id
	@GeneratedValue
	private Long id;
	private String nickname;
	private String email;
	private String avatar;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createTime;

	@ManyToOne
	private BlogPO blog;

	@OneToMany(mappedBy = "parentComment")
	private List<CommentPO> replyComments = new ArrayList<>();
	@ManyToOne
	private CommentPO parentComment;

	public CommentPO() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public BlogPO getBlog() {
		return blog;
	}

	public void setBlog(BlogPO blog) {
		this.blog = blog;
	}

	public List<CommentPO> getReplyComments() {
		return replyComments;
	}

	public void setReplyComments(List<CommentPO> replyComments) {
		this.replyComments = replyComments;
	}

	public CommentPO getParentComment() {
		return parentComment;
	}

	public void setParentComment(CommentPO parentComment) {
		this.parentComment = parentComment;
	}

	@Override
	public String toString() {
		return "CommentPO [id=" + id + ", nickname=" + nickname + ", email=" + email + ", avatar=" + avatar
				+ ", createTime=" + createTime + "]";
	}

}
