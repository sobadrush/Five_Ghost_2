package com.ctbc.handler;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice // 會攔截所有有@Controller註解的控制器
public class ControllerExceptionHandler {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	// ModelAndView控制返回頁面及輸出訊息
	@ExceptionHandler(Exception.class) // 標示這個方法是用來做異常處理的(這裡的參數Exception代表是Exception級別的)
	public ModelAndView exceptionHandler(HttpServletRequest request, Exception e) throws Exception {
		// 記錄錯誤訊息
		logger.error("Request URL : {}, Exception : {}", request.getRequestURL(), e);

		// 判斷status像是404之類的，這裡有自訂NotFoundException
		if (AnnotationUtils.findAnnotation(e.getClass(), ResponseStatus.class) != null) {
			throw e;
		}

		ModelAndView mv = new ModelAndView();
		mv.addObject("url", request.getRequestURL());
		mv.addObject("exception", e);
		mv.setViewName("error/error");
		return mv;
	}
}
